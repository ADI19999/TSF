# <center>TSF TASK 1 - GRIP MARCH'21</center>
## <center>ADITYA AMBWANI<center>

# <center>Prediction Using Supervised ML<center>

### Aim:- To predict the percentage of students based on number of study hours.

[The Sparks Foundation](https://www.thesparksfoundationsingapore.org/)
[GRIP MARCH'21](https://www.linkedin.com/company/the-sparks-foundation/)


```python
# importing libraries
import numpy as np
import pandas as pan
import matplotlib.pyplot as mat
```


```python
# Reading Data
data = pan.read_csv('https://raw.githubusercontent.com/AdiPersonalWorks/Random/master/student_scores%20-%20student_scores.csv')
```


```python
# Calculating number of rows and coloumns
data.shape
```




    (25, 2)




```python
# No. of rows = 25
# No. of coloumns = 2
# Displaying dataset in tabular form
data.head(25)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.5</td>
      <td>20</td>
    </tr>
    <tr>
      <th>6</th>
      <td>9.2</td>
      <td>88</td>
    </tr>
    <tr>
      <th>7</th>
      <td>5.5</td>
      <td>60</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8.3</td>
      <td>81</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2.7</td>
      <td>25</td>
    </tr>
    <tr>
      <th>10</th>
      <td>7.7</td>
      <td>85</td>
    </tr>
    <tr>
      <th>11</th>
      <td>5.9</td>
      <td>62</td>
    </tr>
    <tr>
      <th>12</th>
      <td>4.5</td>
      <td>41</td>
    </tr>
    <tr>
      <th>13</th>
      <td>3.3</td>
      <td>42</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1.1</td>
      <td>17</td>
    </tr>
    <tr>
      <th>15</th>
      <td>8.9</td>
      <td>95</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2.5</td>
      <td>30</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1.9</td>
      <td>24</td>
    </tr>
    <tr>
      <th>18</th>
      <td>6.1</td>
      <td>67</td>
    </tr>
    <tr>
      <th>19</th>
      <td>7.4</td>
      <td>69</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2.7</td>
      <td>30</td>
    </tr>
    <tr>
      <th>21</th>
      <td>4.8</td>
      <td>54</td>
    </tr>
    <tr>
      <th>22</th>
      <td>3.8</td>
      <td>35</td>
    </tr>
    <tr>
      <th>23</th>
      <td>6.9</td>
      <td>76</td>
    </tr>
    <tr>
      <th>24</th>
      <td>7.8</td>
      <td>86</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plotting the data on a graph 
# Scatter plot
mat.scatter(x='Hours', y='Scores', data=data)
mat.xlabel('No. of Hours')
mat.ylabel('Scores obtained')
mat.show()
```


    
![png](output_8_0.png)
    


RESULT:- As the no. of hours increase, the marks obtained by student increaase. So study more!!!


```python
x=data.iloc[:,:-1]
y=data.iloc[:,1]
```


```python
# Splitting our data set into training and testing
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y,test_size = 0.2, random_state =0)
```


```python
# Linear regression on our trained dataset
from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(x_train,y_train)
```




    LinearRegression()




```python
# Plotting linear regression on our actual plot
mat.scatter(x,y)
mat.plot(x,lr.coef_*x +lr.intercept_)
mat.xlabel('Hours')
mat.ylabel('Scores')
mat.show()
```


    
![png](output_13_0.png)
    



```python
#Prediction of the scores obtained
y_pd = lr.predict(x_test)
```


```python
#Comparison
y_pdfinal = pan.DataFrame({'Actual Scores':y_test,'Predicted Scores':y_pd})
y_pdfinal.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual Scores</th>
      <th>Predicted Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>20</td>
      <td>16.884145</td>
    </tr>
    <tr>
      <th>2</th>
      <td>27</td>
      <td>33.732261</td>
    </tr>
    <tr>
      <th>19</th>
      <td>69</td>
      <td>75.357018</td>
    </tr>
    <tr>
      <th>16</th>
      <td>30</td>
      <td>26.794801</td>
    </tr>
    <tr>
      <th>11</th>
      <td>62</td>
      <td>60.491033</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Evaluating the trained dataset on giving hours studied and obtainig the marks
# Hours studied = 9.25/day
hr = [[9.25]]
marks = lr.predict(hr)
res = (marks[0])
print(res)
```

    93.69173248737538
    

RESULT:- The score obtained is 93.69 if a student studies 9.25hrs/day


```python

```
